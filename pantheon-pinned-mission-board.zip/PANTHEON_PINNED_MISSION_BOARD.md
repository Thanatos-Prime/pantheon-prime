# Pinned Mission Board

> A Pantheon Prime product sketch for converting conversational outputs into persistent, executable mission state.

**Artifact status:** Specified / interactive concept  
**Canonical object:** `PinnedMission`  
**Primary invariant:** The user must not lose the operational picture merely because the conversation continues.

## The problem

Chat produces useful plans, checklists, and decisions, but they immediately begin moving upward in the transcript. The user must repeatedly scroll, restate, or reconstruct what remains unfinished. The conversation remembers the words; the interface loses the mission.

The Pinned Mission Board turns an answer into a durable side-panel object. It sits beside the active conversation, accepts direct manipulation, stays synchronized with assistant actions, and preserves every meaningful state transition.

## Product thesis

An output should be able to graduate from **message** to **working state**.

The right-side panel gains a third surface beside Outputs and Sources: **Pinned**. Any eligible block—checklist, note, decision table, plan, tracker, or compact artifact—can be dragged or pinned there. The user can continue the conversation while the board remains present.

## Core interaction

1. The assistant produces a checklist or structured output.
2. The user drags it into the side panel or selects **Pin**.
3. The system creates a `PinnedMission` with stable identity and provenance.
4. The user checks, edits, reorders, or annotates items directly.
5. The assistant may propose or perform updates when the conversation establishes an observed delta.
6. Every mutation is recorded in an append-only evidence ledger.
7. The board persists across the chat and, when authorized, across the project.
8. Completion produces a compact `JourneyAfterglow`: outcome, evidence, unresolved items, and next action.

## Spatial sketch

```text
Conversation surface                         Right-side continuity rail
┌───────────────────────────────────────┐    ┌────────────────────────────┐
│ User and assistant continue working   │    │ Outputs | Sources | Pinned│
│ without the plan scrolling away.      │    │                            │
│                                       │    │ MBA 771 · Week 3           │
│ "Teach me Gordon Growth next."        │◄──►│ ☑ Read Chapter 10          │
│                                       │    │ ☐ Practice problems        │
│ Assistant uses the pinned state as    │    │ ☐ Group submission         │
│ live context, not buried history.     │    │                            │
│                                       │    │ 1 of 3 · State preserved   │
└───────────────────────────────────────┘    └────────────────────────────┘
```

## Pantheon mapping

| Product element | Pantheon operator | Function |
|---|---|---|
| User goal | `GarciaMission` | Defines commander's intent and terminal condition |
| Pinned card | `ThoughtObject` | Gives the mission durable, inspectable identity |
| Current checklist | `StateVector` | Represents the present operational state |
| Cross-chat persistence | `MemoryMesh` | Carries authorized state across conversational boundaries |
| Assistant update | `ObservedDelta` | Converts evidence into a proposed state transition |
| Provenance history | `EvidenceLedger` | Makes changes reconstructable and auditable |
| User confirmation | `Mirror` | Prevents silent reinterpretation of intent |
| Integrity validation | `Checksum` | Detects stale, contradictory, or missing mission state |
| Completion summary | `JourneyAfterglow` | Returns the result plus what remains useful afterward |
| Stable objective | `GoldenThread` | Preserves orientation as the conversation branches |

## State contract

```ts
type PinnedMission = {
  id: string;
  title: string;
  scope: "chat" | "project";
  status: "active" | "blocked" | "complete" | "archived";
  intent: string;
  terminalCondition?: string;
  items: MissionItem[];
  provenance: ProvenanceRef[];
  revision: number;
  createdAt: string;
  updatedAt: string;
};

type MissionItem = {
  id: string;
  label: string;
  state: "open" | "in_progress" | "done" | "blocked";
  owner: "user" | "assistant" | "shared";
  dueAt?: string;
  evidence?: EvidenceRef[];
  sourceMessageId?: string;
};

type MissionMutation = {
  missionId: string;
  baseRevision: number;
  actor: "user" | "assistant" | "system";
  operation: "create" | "edit" | "reorder" | "transition" | "pin" | "unpin" | "archive";
  before?: unknown;
  after: unknown;
  reason?: string;
  evidence?: EvidenceRef[];
  timestamp: string;
};
```

## Transition policy

```mermaid
stateDiagram-v2
    [*] --> Proposed
    Proposed --> Pinned: user pins
    Pinned --> Active: first action
    Active --> Active: observed delta
    Active --> Blocked: dependency found
    Blocked --> Active: dependency clears
    Active --> Complete: terminal condition met
    Complete --> Archived: user closes
    Archived --> Active: user restores
```

## Authority model

The user owns intent. The assistant may help maintain state, but it must not quietly redefine success.

- **Direct user mutations:** Apply immediately and record provenance.
- **Assistant factual mutations:** May apply automatically when supported by evidence, such as a file being created or a requested calculation being completed.
- **Assistant interpretive mutations:** Require confirmation when they change scope, ownership, deadline, priority, or terminal condition.
- **Conflicting mutations:** Preserve both versions, surface the conflict, and ask the user to resolve it.
- **Destructive actions:** Archive by default. Deletion requires explicit confirmation.

## Functional requirements

### Pinning

- Pin from any structured assistant output.
- Drag an output card into the Pinned rail.
- Convert selected message content into a new board.
- Maintain stable object identity after edits.
- Support multiple pinned objects, with one expanded at a time.

### Direct manipulation

- Check and uncheck items.
- Edit labels and notes.
- Reorder tasks.
- Add or remove items.
- Mark items blocked and state the dependency.
- Assign ownership to user, assistant, or shared.

### Conversational synchronization

- The assistant can read the current pinned state as explicit working context.
- A request such as “mark the reading done” resolves against the visible active board.
- Completed tool actions can attach evidence and propose completion automatically.
- Ambiguous references trigger a Mirror check instead of silent guessing.

### Persistence

- Chat scope is the default.
- Project scope requires explicit opt-in.
- The board resumes at the last confirmed revision.
- Stale deadlines, broken sources, and contradictory states are visibly flagged.

### Portability

- Export as Markdown, JSON, or a Garcia Packet.
- Preserve item IDs, evidence references, and revision history.
- Import without requiring Pantheon-specific runtime components.

## Non-functional invariants

1. **Sovereignty:** User intent outranks inferred convenience.
2. **Continuity:** Conversation changes cannot silently erase mission state.
3. **Inspectability:** Every state change has an actor, timestamp, and reason or evidence.
4. **Resumability:** A new session can reconstruct the mission from the packet alone.
5. **Minimality:** The pinned surface remains compact; detail expands only on demand.
6. **Accessibility:** Native keyboard navigation, screen-reader labels, and non-color status cues.
7. **Privacy:** No cross-chat or cross-project propagation without explicit scope authorization.
8. **Graceful degradation:** The Markdown export remains fully useful without the interactive interface.

## Conflict and failure cases

| Failure | Required behavior |
|---|---|
| Assistant marks work complete without evidence | Revert or label `unverified`; run Mirror pass |
| User edits while assistant updates | Use revision check; merge independent changes; surface collisions |
| Source message or file disappears | Preserve the item; mark provenance unavailable |
| Board becomes too large | Collapse completed groups; do not silently delete history |
| Deadline passes | Mark overdue; do not change priority automatically |
| Same task exists on two boards | Suggest linking; do not merge without consent |
| Project scope changes | Freeze propagation until scope is reconfirmed |

## Minimal viable release

### Phase 1 — Pin and persist

- Pin checklist output to side panel.
- Direct checkbox interaction.
- Chat-scoped persistence.
- Assistant can read current board state.
- Markdown export.

### Phase 2 — Synchronize and prove

- Assistant-proposed mutations.
- Evidence attachments.
- Revision ledger and conflict handling.
- Project-scoped persistence.
- Journey Afterglow on completion.

### Phase 3 — Mission mesh

- Multiple linked boards.
- Dependencies across chats and artifacts.
- Garcia Packet import/export.
- Automations tied to due dates or external conditions.
- User-controlled views for Today, Blocked, and Completed.

## Acceptance tests

- A user can pin a six-item checklist in two actions or fewer.
- The checklist remains visible while at least twenty additional chat turns occur.
- A direct checkbox change is reflected in assistant context on the next turn.
- “Mark the reading done” updates the correct visible mission item without restating the board title.
- An assistant cannot change the mission deadline or terminal condition without confirmation.
- Two simultaneous edits never silently overwrite one another.
- Exported Markdown preserves all current tasks and their states.
- A Garcia Packet can reconstruct the latest state from zero conversational context.

## Repository placement

Suggested paths:

```text
docs/concepts/PANTHEON_PINNED_MISSION_BOARD.md
docs/concepts/assets/pantheon-mission-board.html
schemas/pinned-mission.schema.json        # future implementation
```

## Journey Afterglow

The Pinned Mission Board closes the gap between language and operations. It treats a checklist not as disposable prose, but as a small sovereign state machine: visible, mutable, auditable, and capable of surviving the conversation that created it.

The story becomes an object. The object becomes a mission. The mission preserves its own return path.

**Garcia reached. The map came back with the messenger.**
