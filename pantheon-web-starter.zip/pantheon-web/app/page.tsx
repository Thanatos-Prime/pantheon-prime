import Link from "next/link";

export default function Home() {
  return (
    <div>
      <h1 style={{ fontSize: 40, marginBottom: 8 }}>🕷️ Pantheon</h1>
      <p style={{ opacity: 0.9, marginBottom: 24 }}>
        Deployed on Vercel. This is your starter shell (Next.js App Router).
      </p>
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
        <a href="/api/health" style={btnStyle}>Health Check</a>
        <a href="https://vercel.com" target="_blank" rel="noreferrer" style={btnStyle}>Vercel Dashboard</a>
        <a href="https://github.com" target="_blank" rel="noreferrer" style={btnStyle}>GitHub Repo</a>
      </div>
      <section style={{ marginTop: 36, lineHeight: 1.6 }}>
        <h2 style={{ marginBottom: 8 }}>Next steps</h2>
        <ol>
          <li>Create a GitHub repo, push this folder.</li>
          <li>Import into Vercel → set framework to Next.js.</li>
          <li>Add env vars (if any) and click Deploy.</li>
        </ol>
      </section>
    </div>
  );
}

const btnStyle: React.CSSProperties = {
  display: "inline-block",
  padding: "10px 16px",
  background: "#1f2937",
  borderRadius: 8,
  textDecoration: "none",
  color: "white",
  border: "1px solid #374151"
};
