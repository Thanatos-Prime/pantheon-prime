# Pantheon — Vercel-Ready Starter

A minimal Next.js (App Router) shell for the Pantheon. Health check included. Deploys cleanly on Vercel.

## Quick Deploy
1. **Download** this folder as a zip and extract.
2. Initialize git & push to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Pantheon web initial"
   gh repo create pantheon-web --public --source=. --remote=origin --push
   ```
   Or create the repo manually on GitHub and:
   ```bash
   git remote add origin <your-repo-url>
   git push -u origin main
   ```
3. **Vercel** → Import Project → pick repo → Framework: **Next.js** → Deploy.
4. (Optional) Add your domain in Vercel Settings → Domains.

## Scripts
- `npm run dev` — local dev
- `npm run build` — production build
- `npm start` — run production server locally

## API
- `GET /api/health` → `{ status: "ok", service: "pantheon-web" }`

## Environment
Add `.env.local` for local development and set the same keys in Vercel (Development / Preview / Production).
See `.env.example` for placeholders.

---
Deployed with ❤️  by your Letter-to-Garcia kit.
